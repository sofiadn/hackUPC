var arnRole = '602454197181';
export default arnRole;
